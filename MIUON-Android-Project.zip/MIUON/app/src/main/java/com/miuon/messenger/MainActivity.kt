package com.miuon.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF090910)
private val Panel = Color(0xFF151522)
private val Purple = Color(0xFF9B5CFF)
private val Muted = Color(0xFFAAA5B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiuonApp() }
    }
}

data class Chat(val title: String, val message: String, val time: String, val initials: String)

@Composable
fun MiuonApp() {
    var selected by remember { mutableStateOf("Чаты") }
    var search by remember { mutableStateOf("") }
    var showWelcome by remember { mutableStateOf(false) }
    val chats = listOf(
        Chat("MIUON Team", "Добро пожаловать в MIUON!", "12:40", "M"),
        Chat("Избранное", "Твои сохранённые сообщения", "Вчера", "★"),
        Chat("Новый чат", "Найди друзей по имени", " ", "+")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MIUON", fontSize = 30.sp, fontWeight = FontWeight.Black,
                            color = Color.White, letterSpacing = 2.sp)
                        Text("ТВОЁ ОБЩЕНИЕ. ТВОЙ МИР.", fontSize = 9.sp,
                            color = Purple, letterSpacing = 2.sp)
                    }
                    Box(Modifier.size(44.dp).background(
                        Brush.linearGradient(listOf(Purple, Color(0xFF5425A8))), CircleShape
                    ), contentAlignment = Alignment.Center) {
                        Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                }
                Spacer(Modifier.height(26.dp))
                Text(selected, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Поиск чатов", color = Muted) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple, unfocusedBorderColor = Panel,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        cursorColor = Purple
                    )
                )
                Spacer(Modifier.height(18.dp))
                if (selected == "Чаты") {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(chats.filter { it.title.contains(search, true) || it.message.contains(search, true) }) { chat ->
                            Row(
                                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp))
                                    .clickable { showWelcome = true }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(50.dp).background(
                                    Brush.linearGradient(listOf(Purple, Color(0xFF38205C))), CircleShape
                                ), contentAlignment = Alignment.Center) {
                                    Text(chat.initials, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(13.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(chat.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                    Text(chat.message, color = Muted, fontSize = 12.sp)
                                }
                                Text(chat.time, color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(if (selected == "Звонки") "Звонки появятся в следующих версиях" else "Профиль MIUON",
                            color = Muted)
                    }
                }
                if (showWelcome) {
                    AlertDialog(
                        onDismissRequest = { showWelcome = false },
                        title = { Text("MIUON") },
                        text = { Text("Это первый прототип интерфейса. Настоящие онлайн-чаты и звонки подключим отдельно.") },
                        confirmButton = { TextButton(onClick = { showWelcome = false }) { Text("Понятно") } },
                        containerColor = Panel,
                        titleContentColor = Color.White,
                        textContentColor = Muted
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 12.dp)
                        .background(Panel, RoundedCornerShape(22.dp)).padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf("Чаты", "Звонки", "Профиль").forEach { tab ->
                        Column(
                            Modifier.weight(1f).clickable { selected = tab }.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(tab, color = if (selected == tab) Purple else Muted,
                                fontWeight = if (selected == tab) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
